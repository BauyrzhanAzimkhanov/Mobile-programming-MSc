package com.example.assignment2

data class UserItem(
    var username: String,
    var profileImage: Int,
    var biography: String
)
