package com.example.assignment2

data class RecyclerViewItem(
    var username: String,
    var image: Int,
    var comment: String,
    var likes: Int
)