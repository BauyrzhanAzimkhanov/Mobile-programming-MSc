package com.example.assignment2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AddPostActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}